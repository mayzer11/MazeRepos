package com.sg.classroster;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class classRosterApplication {

	public static void main(String[] args) {
		SpringApplication.run(classRosterApplication.class, args);
	}

}
